﻿using petstore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using petstore.Services;
using petstore.Models;
using petstore.Services;
using System.Net.Http;

namespace petstore.Controllers
{
    public class FilesController : Controller
    {
        private readonly AzureFileShareService _fileShareService;
        private readonly HttpClient _httpClient;
        public FilesController(AzureFileShareService fileShareService, HttpClient httpClient)
        {
            _fileShareService = fileShareService;
            _httpClient = httpClient;
        }
        public async Task<IActionResult> Index()
        {
            List<FileModel> files;
            try
            {
                files = await _fileShareService.ListFilesAsync("uploads");
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Failed to load files: {ex.Message}";
                files = new List<FileModel>();
            }

            return View(files);
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            using (var fileContent = new MultipartFormDataContent())
            {
                using (var stream = file.OpenReadStream())
                {
                    fileContent.Add(new StreamContent(stream), "file", file.FileName);


                    var fileResponse = await _httpClient.PostAsync(
                        "https://st10343093filestorage.azurewebsites.net/api/UploadFileToShare?code=9a6DuXKj3eGVDqIg5NHAKjYSfDVOKoKdJZ_HkMapfqAsAzFu00WYqw%3D%3D",
                        fileContent
                    );


                    if (fileResponse.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return BadRequest("Failed upload File!");
                    }
                }
            }
        }

        // Handle file download
        [HttpGet]
        public async Task<IActionResult> DownloadFile(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return BadRequest("File name cannot be null or empty.");
            }

            try
            {
                var fileStream = await _fileShareService.DownloadFileAsync("uploads", fileName);

                if (fileStream == null)
                {
                    return NotFound($"File '{fileName}' not found.");
                }

                return File(fileStream, "application/octet-stream", fileName);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error downloading file: {ex.Message}");
            }
        }
    }
}