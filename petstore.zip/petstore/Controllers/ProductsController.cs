﻿using Microsoft.AspNetCore.Mvc;
using petstore.Models;
using petstore.Services;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text;


namespace petstore.Controllers
{
    public class ProductsController : Controller
    {
        private readonly BlobService _blobService;
        private readonly TableStorageService _tableStorageService;
        private readonly QueueService _queueService;
        private readonly HttpClient _httpClient;
        public ProductsController(BlobService blobService, TableStorageService tableStorageService, QueueService queueService, HttpClient httpClient)

        {

            _blobService = blobService;

            _tableStorageService = tableStorageService;

            _queueService = queueService;

            _httpClient = httpClient;

        }



        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct(Product product, IFormFile file)
        {
          
            if (file != null)
            {
                var fileName = Path.GetFileName(file.FileName);


                using var stream = file.OpenReadStream();


                await _blobService.UploadAsync(stream, fileName);


                product.ImageUrlPath = "https://st10343093cldv6212.blob.core.windows.net/products/" + fileName;
            }

            if (ModelState.IsValid)
            {
               
                var products = await _tableStorageService.GetAllProductsAsync();

                int nextProductId = products.Any() ? products.Max(p => (p.ProductId)) + 1 : 1;

                int nextRowKey = products.Any() ? products.Max(p => int.Parse(p.RowKey)) + 1 : 1;

                
                product.PartitionKey = product.Category ?? "DefaultCategory";  
                product.RowKey = nextRowKey.ToString();  
                product.ProductId = nextProductId;


                var json = JsonConvert.SerializeObject
                 (
                     new Product
                     {
                         ProductId = nextProductId,
                         PartitionKey = product.Category ?? "DefaultCategory",
                         RowKey = nextRowKey.ToString(),
                         ProductDescription = product.ProductDescription,
                         Name = product.Name,
                         Price = product.Price,
                         Category = product.Category,
                         ImageUrlPath = product.ImageUrlPath,
                         Timestamp = product.Timestamp,
                     }
                 );


                var content = new StringContent(json, Encoding.UTF8, "application/json");


                var response = await _httpClient.PostAsync("https://st10343093tablestorage.azurewebsites.net/api/AddProductFunction?code=Hjys2NCpjPdkyqw48tKGo5PYMgEaIXdRIncSXo5ifMBdAzFuNXlqHA%3D%3D", content);


                if (!response.IsSuccessStatusCode)
                {
                    return BadRequest("Failed to add product.");
                }

                string imageUploadMessage = $"Product ID:{product.ProductId}, Image url: {product.ImageUrlPath}, Status: Uploaded Successfully";
                await _queueService.SendMessageAsync("imageupload", imageUploadMessage);

                return RedirectToAction("Index");
            }

            return View(product);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteProduct(string partitionKey, string rowKey, Product product)
        {
            if (product != null && !string.IsNullOrEmpty(product.ImageUrlPath))
            {
               
                await _blobService.DeleteBlobAsync(product.ImageUrlPath);
            }

            await _tableStorageService.DeleteProductAsync(partitionKey, rowKey);

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index()
        {
            var products = await _tableStorageService.GetAllProductsAsync();
            foreach (var product in products)
            {
                Console.WriteLine($"Product: {product.Name}, Price: {product.Price}");
            }
            return View(products);
        }
    }
}