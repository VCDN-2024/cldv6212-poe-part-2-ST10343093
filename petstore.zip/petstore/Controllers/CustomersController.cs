﻿using petstore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using petstore.Services;
using System.Linq;
using petstore.Models;
using petstore.Services;

namespace petstore.Controllers
{
    public class CustomersController : Controller
    {
        private readonly TableStorageService _tableStorageService;

        public CustomersController(TableStorageService tableStorageService)
        {
            _tableStorageService = tableStorageService;
        }

        public async Task<IActionResult> Index()
        {
            var customers = await _tableStorageService.GetAllCustomersAsync();
            return View(customers);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Customer customer)
        {
            // Set PartitionKey  and RowKey for the new customer
            customer.PartitionKey = "CustomersPartition"; // Adjust as necessary for logical partitioning

            customer.RowKey = Guid.NewGuid().ToString();

            // Fetch all customers to determine the next available integer ID
            var customers = await _tableStorageService.GetAllCustomersAsync();

            // Determine the next available CustomerId
            int nextCustomerId = customers.Any() ? customers.Max(c => (c.CustomerId)) + 1 : 1;

            // Set the RowKey to the new CustomerId
            customer.CustomerId = nextCustomerId;

            // Add customer to the table
            await _tableStorageService.AddCustomerAsync(customer);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Delete(string partitionKey, string rowKey)
        {
            // Delete customer from the table
            await _tableStorageService.DeleteCustomerAsync(partitionKey, rowKey);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Details(string partitionKey, string rowKey)
        {
            var customer = await _tableStorageService.GetCustomerAsync(partitionKey, rowKey);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }
        // GET: Customers/Edit/{partitionKey}/{rowKey}
        public async Task<IActionResult> Edit(string partitionKey, string rowKey)
        {
            var customer = await _tableStorageService.GetCustomerAsync(partitionKey, rowKey);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }

        // POST: Customers/Edit/{partitionKey}/{rowKey}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string partitionKey, string rowKey, Customer customer)
        {
            if (partitionKey != customer.PartitionKey || rowKey != customer.RowKey)
            {
                return BadRequest();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Use the new UpdateCustomerAsync method to update the customer in Azure Table Storage
                    await _tableStorageService.UpdateCustomerAsync(customer);
                }
                catch
                {
                    // Handle errors if needed
                    return View(customer);
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }
    }
}