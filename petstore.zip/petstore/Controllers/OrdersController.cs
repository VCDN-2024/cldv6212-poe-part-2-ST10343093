﻿using petstore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using petstore.Services;
using System.Reflection;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using petstore.Models;
using petstore.Services;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;



namespace petstore.Controllers
{
    public class OrdersController : Controller
    {
        private readonly TableStorageService _tableStorageService;
        private readonly HttpClient _httpClient;
        private readonly QueueService _queueService;
        

        public OrdersController(TableStorageService tableStorageService, QueueService queueService , HttpClient httpClient)
        {
            _tableStorageService = tableStorageService;
            _queueService = queueService;
            _httpClient = httpClient;
        }

        // Action to display all orders
        public async Task<IActionResult> Index()
        {
            var orders = await _tableStorageService.GetAllOrdersAsync();
            return View(orders);
        }

        public async Task<IActionResult> Delete(string partitionKey, string rowKey)
        {
            // Delete Table entity
            await _tableStorageService.DeleteOrderAsync(partitionKey, rowKey);

            return RedirectToAction("Index");
        }

        // Action to display the form for creating a new order
        public async Task<IActionResult> Create()
        {
            try
            {
                var customers = await _tableStorageService.GetAllCustomersAsync();
                var products = await _tableStorageService.GetAllProductsAsync();

                ViewData["Customers"] = new SelectList(customers, "CustomerId", "CustomerName");
                ViewData["Products"] = new SelectList(products, "ProductId", "Name");

                return View();
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"An error occurred while loading the create page: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while loading the create page.");
                return View();
            }
        }

        // Action to handle the form submission and create a new order
        [HttpPost]
        public async Task<IActionResult> Create(Order order)
        {
            var product = await _tableStorageService.GetProductAsync("ProductsPartition", order.ProductId.ToString());

            if (ModelState.IsValid)
            {
                try
                {
                    // Ensure Order_Date is not null
                    if (!order.OrderDate.HasValue)
                    {
                        ModelState.AddModelError("Order_Date", "Order Date is required.");
                        return View(order);
                    }

                    order.OrderDate = DateTime.SpecifyKind(order.OrderDate.Value, DateTimeKind.Utc);

                    // Generate a new unique Order_Id
                    var allOrders = await _tableStorageService.GetAllOrdersAsync();
                    order.OrderId = (allOrders.Count > 0) ? allOrders.Max(o => o.OrderId) + 1 : 1;

                    // Set PartitionKey and RowKey
                    order.PartitionKey = "OrdersPartition";
                    order.RowKey = Guid.NewGuid().ToString();



                    // Add order to table storage
                    await _tableStorageService.AddOrderAsync(order);

                    // Send a message to the queue
                    var json = JsonConvert.SerializeObject
                     (
                         new Order
                         {
                             OrderId = order.OrderId,
                             PartitionKey = order.PartitionKey,
                             RowKey = order.RowKey,
                             Timestamp = order.Timestamp,
                             OrderDate = order.OrderDate,
                             CustomerId = order.CustomerId,
                             ProductId = order.ProductId,
                         }
                     );


                    var contentQueue = new StringContent(json, Encoding.UTF8, "application/json");
                    var response = await _httpClient.PostAsync("https://st10343093queuestoragefunction.azurewebsites.net/api/ProcessOrders?code=OImTcNxnqcnXNNGPNvouSKIsGQ9CNcLZMYWGc2rVR7x3AzFuP3oPNw%3D%3D", contentQueue);
                    response.EnsureSuccessStatusCode();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    // Log the exception
                    Console.WriteLine($"An error occurred while processing the order: {ex.Message}");
                    ModelState.AddModelError("", "An error occurred while processing your order.");
                }

            }
            // Reload the data in case of error
            try
            {
                var customers = await _tableStorageService.GetAllCustomersAsync();
                var products = await _tableStorageService.GetAllProductsAsync();

                ViewData["Customers"] = new SelectList(customers, "Customer_Id", "Name", order.CustomerId);
                ViewData["Products"] = new SelectList(products, "Product_Id", "Name", order.ProductId);
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"An error occurred while reloading data: {ex.Message}");
                ViewData["Customers"] = new SelectList(new List<Customer>(), "Customer_Id", "Name");
                ViewData["Products"] = new SelectList(new List<Product>(), "Product_Id", "Name");
            }

            return View(order);
        }

    }

}