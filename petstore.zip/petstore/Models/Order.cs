﻿using Azure.Data.Tables;
using Azure;
using System.ComponentModel.DataAnnotations;

namespace petstore.Models
{
    public class Order : ITableEntity
    {
        [Key]
        public int OrderId { get; set; }

        public string? PartitionKey { get; set; }
        public string? RowKey { get; set; }
        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
        //Introduce validation sample
        [Required(ErrorMessage = "Please select a customer.")]
        public int? CustomerId { get; set; } // FK to the Customer who made the order

        [Required(ErrorMessage = "Please select a product.")]
        public int ProductId { get; set; } // FK to the Product being ordered

        // [Required(ErrorMessage = "Please select the date.")]
        public DateTime? OrderDate { get; set; }


    }
}