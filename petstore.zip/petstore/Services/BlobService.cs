﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;

using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using petstore.Models;
using System.IO;
using System.Threading.Tasks;

namespace petstore.Services
{
    public class BlobService
    {
        private readonly HttpClient _httpClient;


        public BlobService(HttpClient httpClient)
        {
            _httpClient = httpClient;

        }

        public async Task UploadAsync(Stream fileStream, string fileName)
        {
            var functionUrl = "https://st10343093blobfunction.azurewebsites.net/api/UploadToBlob?code=9Rxj6x4Sb6_VpLjMR1TxEOADlJKbK8C0V2kp1a0z4RQ5AzFu6z9cqQ%3D%3D"; // Change to your function URL

            using var content = new StreamContent(fileStream);
            content.Headers.Add("file-name", fileName);  // Pass the file name in headers

            var response = await _httpClient.PostAsync(functionUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to upload to Blob Storage");
            }
        }

        // Method to delete a blob by calling the Azure Function
        public async Task DeleteBlobAsync(string blobUri)
        {
            var functionUrl = $"https://st10343093blobfunction.azurewebsites.net/api/DeleteBlob?code=7S09XcghmV5LUYYEmsX5TwTtWVXiGBbZGKbfpPYgfPVRAzFugM18nA%3D%3D&blobUri={Uri.EscapeDataString(blobUri)}";

            var response = await _httpClient.DeleteAsync(functionUrl);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to delete the blob from Blob Storage");
            }
        }


    }
}